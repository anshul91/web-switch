import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class homeAutomation extends PApplet {


Serial myPort;

public void setup(){
  
  myPort = new Serial(this, Serial.list()[1], 9600);
  myPort.clear();
}
public void draw(){
  delay(2000);
  String apiUrl = "http://www.parikshacrack.com/gadgetProgrammers/homeAutomation/callApi.php?";
    String callFxn = "method=updateSwitchStatus";
    apiUrl = apiUrl+""+callFxn;
    println(apiUrl);
    try {
      //calling api which returns json object
      JSONObject json = loadJSONObject(apiUrl);
      //getting msg arg.
      String msg = json.getString("msg");
      //code returned from api
      int retCode = json.getInt("retCode");
      String currState = json.getString("retState");
      println(("curr State: "+currState));
      if(currState.equals("1")){
        println("Switch On Successfully!");
        //for(int i=10;i<20;i++){
          myPort.write("1");
          
        //}
        delay(200);
      }else if(currState.equals("0")){
        println("Switch Off Successfully!");
       //for(int i=10;i<20;i++){
          myPort.write("0");
          delay(100);
        //}
      }else if(currState == "-2"){
        println(msg);
      }
      
    }catch(Exception e){
      println("Exception :"+e.getMessage());
    }
    callFxn = "";
  }
  public void settings() {  size(200,200); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#A0D5FF", "--stop-color=#cccccc", "homeAutomation" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
